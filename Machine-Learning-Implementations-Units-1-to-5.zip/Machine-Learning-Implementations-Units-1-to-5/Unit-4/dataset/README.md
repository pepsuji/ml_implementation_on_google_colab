# Unit 4 Dataset

The notebook loads **`Heartrate_sleep_data.csv`**, uploaded to Colab with `files.upload()`.

| Property | Value |
|---|---|
| Rows | 34,403 |
| Columns | `dateTime` (format `m/d/yy HH:MM`), `bpm` (integer heart rate), `level` (sleep stage: `light`, `deep`, `rem`/`REM`, `wake`) |
| Sampling | One reading per minute, starting 26 June 2024 |

Example rows:

```
dateTime,bpm,level
6/26/24 01:52,75,deep
6/26/24 01:53,71,deep
6/26/24 01:54,71,deep
```

**Not included in this repository.** The notebook does not record where the file came from, and the file was not available when this repository was prepared.

To run the notebook, upload any CSV with the same three columns when the upload cell runs. Minute-level heart rate with Fitbit-style sleep stages (`wake`, `light`, `deep`, `rem`) matches this format.
