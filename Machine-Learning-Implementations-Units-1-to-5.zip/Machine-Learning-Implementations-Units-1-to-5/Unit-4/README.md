# Unit 4: Sleep Stage Classification from Heart Rate with Random Forest

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/pepsuji/Machine-Learning-Implementations-Units-1-to-5/blob/main/Unit-4/Unit_4_Implementation.ipynb)

**Notebook:** [`Unit_4_Implementation.ipynb`](Unit_4_Implementation.ipynb)

## 1. Project Title

Sleep Stage Classification from Wearable Heart-Rate Data Using a Random Forest Classifier.

## 2. Problem Statement

Wearable devices record heart rate continuously during sleep. The task is to predict the current sleep stage (light, deep or REM) from recent heart-rate readings alone, and to evaluate the model on recording sessions it has never seen.

## 3. Objective

- Clean a minute-level heart-rate and sleep-stage log.
- Split the log into recording sessions and engineer rolling heart-rate features within each session.
- Train a Random Forest classifier and evaluate it with a session-grouped split, so no session appears in both training and testing.
- Interpret feature importance, make an example prediction and save the trained model.

## 4. Dataset Description and Source

| Property | Value |
|---|---|
| File | `Heartrate_sleep_data.csv` (uploaded to Colab with `files.upload()`) |
| Rows | 34,403 |
| Columns | 3: `dateTime`, `bpm`, `level` |
| Time range | Starts 26 June 2024, one reading per minute |
| Missing values | None |

Raw label counts: light 16,424; deep 8,174; wake 3,938; REM 3,414 (`REM`) and 2,453 (`rem`).

**Source:** the notebook loads a locally uploaded file and does not record where it came from. The CSV is not included in this repository; see [`dataset/README.md`](dataset/README.md) for the expected format and how to supply it.

## 5. Machine Learning Algorithm Used

**Random Forest Classifier** (`sklearn.ensemble.RandomForestClassifier`): an ensemble of decision trees trained on bootstrap samples, with predictions made by majority vote.

```python
RandomForestClassifier(n_estimators=200, max_depth=12, min_samples_split=5,
                       class_weight="balanced", random_state=42, n_jobs=-1)
```

`class_weight="balanced"` compensates for light sleep being about twice as common as deep or REM sleep.

## 6. Libraries and Dependencies

`pandas`, `numpy`, `matplotlib`, `seaborn`, `scikit-learn`, `joblib`, `google.colab`.

## 7. Data Preprocessing Steps

1. Parse `dateTime` with the format `%m/%d/%y %H:%M`; coerce `bpm` to numeric.
2. Drop rows with missing timestamp, heart rate or label.
3. Keep heart rates between 30 and 220 bpm.
4. Standardise labels (strip and lower-case), which merges `REM` and `rem`.
5. Sort chronologically and drop duplicate timestamps.

All 34,403 rows remained after cleaning.

## 8. Feature Selection or Engineering

- **Session segmentation:** a new session starts whenever the gap between readings is more than 5 minutes, giving **98 sessions**.
- **Rolling features** (computed within each session over the last 5 readings): `hr_mean_5`, `hr_std_5`, `hr_min_5`, `hr_max_5`.
- **Point features:** `hr_current` (current bpm) and `hr_change` (difference from the previous reading).
- Rows without 5 previous readings are dropped, and only the light, deep and REM stages are kept (wake is excluded).

Final data: **30,142 rows × 6 features**; classes light 16,215, deep 8,094, REM 5,833.

## 9. Model Implementation

The Random Forest above is trained on the six heart-rate features. The trained model, feature list and class names are saved together with `joblib` as `sleep_stage_model.pkl`, then reloaded to confirm it gives the same prediction.

## 10. Training and Testing Methodology

`GroupShuffleSplit` with an 80/20 split by `session_id` (`random_state=42`):

| | Observations | Sessions |
|---|---|---|
| Training | 24,246 | 76 |
| Testing | 5,896 | 19 |
| Shared sessions | | **0** |

Splitting by session avoids leakage: neighbouring minutes from the same night are highly similar, so a random row split would overstate accuracy.

## 11. Evaluation Metrics

Accuracy, per-class precision, recall and F1-score (`classification_report`), and the confusion matrix.

## 12. Actual Results and Observations

**Test accuracy: 62.47%**

| Class | Precision | Recall | F1-score | Support |
|---|---|---|---|---|
| Light Sleep | 0.75 | 0.62 | 0.68 | 3,219 |
| Deep Sleep | 0.46 | 0.70 | 0.56 | 1,187 |
| REM Sleep | 0.59 | 0.57 | 0.58 | 1,490 |
| Macro average | 0.60 | 0.63 | 0.61 | 5,896 |
| Weighted average | 0.65 | 0.62 | 0.63 | 5,896 |

Feature importance:

| Feature | Importance |
|---|---|
| hr_mean_5 | 0.3746 |
| hr_max_5 | 0.2684 |
| hr_min_5 | 0.1413 |
| hr_std_5 | 0.0971 |
| hr_current | 0.0842 |
| hr_change | 0.0345 |

Example prediction (illustrative readings, not from the dataset): heart rates `[70, 68, 65, 63, 62]` are classified as **REM** with an estimated probability of 0.87 (light 0.09, deep 0.04). The reloaded model gives the same prediction.

Observations:

- Heart rate alone separates the three stages moderately well on unseen sessions (about 62% accuracy against a 33% chance level for three classes).
- Deep sleep has high recall (0.70) but low precision (0.46): the balanced class weights make the model predict deep sleep often, and many light-sleep minutes are labelled as deep.
- The 5-minute rolling mean is the most informative feature; single-minute values and changes add less.

## 13. Visualisations and Interpretation

| Plot | Interpretation |
|---|---|
| ![Stage distribution](outputs/01_sleep_stage_distribution.png) | Light sleep is the most common stage, followed by deep sleep, REM and wake. |
| ![HR by stage](outputs/02_heart_rate_by_sleep_stage.png) | Median heart rate is lowest in deep sleep (about 56 bpm), higher in light sleep (about 60) and REM (about 64), and highest when awake (about 70). The boxes overlap, which is why heart rate alone cannot separate the stages perfectly. |
| ![HR over time](outputs/03_heart_rate_over_time.png) | The first 300 readings show heart rate fluctuating through the night. |
| ![Confusion matrix](outputs/04_confusion_matrix.png) | Light sleep: 2,001 correct, 747 predicted as deep, 471 as REM. Deep: 828 correct. REM: 854 correct, with 425 predicted as light. Most errors involve light sleep. |
| ![Feature importance](outputs/05_feature_importance.png) | `hr_mean_5` and `hr_max_5` together account for about 64% of the importance. |
| ![Example probabilities](outputs/06_example_prediction_probabilities.png) | Class probabilities for the example input; REM is strongly favoured. |

## 14. Conclusion

A Random Forest trained on six rolling heart-rate features predicts light, deep and REM sleep with 62.47% accuracy on recording sessions it did not see during training. The session-grouped split gives a realistic estimate. Heart rate on its own leaves the stages overlapping, so adding motion (accelerometer) data or longer time windows would be the natural next step.
