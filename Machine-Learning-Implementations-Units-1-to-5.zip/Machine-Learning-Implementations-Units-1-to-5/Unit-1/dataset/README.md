# Unit 1 Dataset

The notebook loads **`Delivery_Logistics.csv`**, uploaded to Colab with `files.upload()`.

| Property | Value |
|---|---|
| Rows | 25,000 |
| Columns | 15 |
| Columns list | `delivery_id`, `delivery_partner`, `package_type`, `vehicle_type`, `delivery_mode`, `region`, `weather_condition`, `distance_km`, `package_weight_kg`, `delivery_time_hours`, `expected_time_hours`, `delayed`, `delivery_status`, `delivery_rating`, `delivery_cost` |

**Not included in this repository.** The notebook does not record where the file was downloaded from, and the file was not available when this repository was prepared.

To run the notebook, place `Delivery_Logistics.csv` in this folder (or upload it when the `files.upload()` cell runs in Colab).
