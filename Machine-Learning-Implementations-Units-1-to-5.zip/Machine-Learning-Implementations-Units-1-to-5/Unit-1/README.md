# Unit 1: Dataset Exploration and Statistical Analysis

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/pepsuji/Machine-Learning-Implementations-Units-1-to-5/blob/main/Unit-1/Unit_1_Implementation.ipynb)

**Notebook:** [`Unit_1_Implementation.ipynb`](Unit_1_Implementation.ipynb)

## 1. Project Title

Dataset Exploration and Statistical Analysis of a Delivery Logistics Dataset.

## 2. Problem Statement

Before any model is trained, the structure, quality and statistical properties of a dataset need to be understood. This unit covers two experiments:

- **Experiment 1:** Import, load and view a dataset.
- **Experiment 2:** Display the summary and statistics of the dataset.

## 3. Objective

- Load a tabular dataset into pandas and inspect its first and last records.
- Report its shape, column names and data types.
- Check for missing values and duplicate rows.
- Compute descriptive statistics (mean, median, mode, standard deviation, variance, minimum and maximum).
- Visualise feature distributions and correlations.

## 4. Dataset Description and Source

| Property | Value |
|---|---|
| File | `Delivery_Logistics.csv` (uploaded to Colab with `files.upload()`) |
| Rows | 25,000 |
| Columns | 15 |
| Missing values | None |
| Duplicate rows | None |

Columns: `delivery_id`, `delivery_partner`, `package_type`, `vehicle_type`, `delivery_mode`, `region`, `weather_condition`, `distance_km`, `package_weight_kg`, `delivery_time_hours`, `expected_time_hours`, `delayed`, `delivery_status`, `delivery_rating`, `delivery_cost`.

The dataset records parcel deliveries by Indian courier partners (for example Delhivery, Xpressbees, Shadowfax, DHL, Ekart, Blue Dart), with package, vehicle, route, weather, timing, rating and cost details.

**Source:** the notebook loads a locally uploaded file and does not record where it was downloaded from. The CSV is not included in this repository; see [`dataset/README.md`](dataset/README.md).

## 5. Machine Learning Algorithm Used

None. This unit is exploratory data analysis (EDA) and descriptive statistics, which is the groundwork for the modelling units that follow.

## 6. Libraries and Dependencies

`pandas`, `numpy`, `matplotlib`, `seaborn`, `google.colab` (for file upload).

## 7. Data Preprocessing Steps

No transformation is applied to the data. The notebook only inspects it:

- `df.head()` / `df.tail()` to view records.
- `df.shape`, `df.columns`, `df.info()` and `df.dtypes` to inspect structure.
- `df.isnull().sum()` and `df.duplicated().sum()` to check quality.

## 8. Feature Selection or Engineering

Not applicable. Numerical columns are selected with `df.select_dtypes(include=np.number)` for statistics and plots.

## 9. Model Implementation

Not applicable (no model is trained in this unit).

## 10. Training and Testing Methodology

Not applicable.

## 11. Evaluation Metrics

Descriptive statistics are computed for the five numerical columns: count, mean, median, mode, standard deviation, variance, minimum, maximum, quartiles, and the Pearson correlation matrix.

## 12. Actual Results and Observations

Numerical summary (from the notebook output):

| Column | Mean | Median | Std | Min | Max |
|---|---|---|---|---|---|
| distance_km | 150.39 | 151.00 | 86.41 | 3.60 | 297.10 |
| package_weight_kg | 25.15 | 25.15 | 14.37 | 0.67 | 49.52 |
| delivery_rating | 3.67 | 4.00 | 1.15 | 1 | 5 |
| delivery_cost | 864.94 | 867.54 | 435.71 | 95.67 | 1632.72 |

Observations:

- The dataset is complete: no missing values and no duplicate rows.
- `distance_km` and `delivery_cost` are almost perfectly correlated (**r = 0.99**), so cost is driven mainly by distance.
- `delivery_rating` has a weak negative correlation with distance (r = -0.13) and with cost (r = -0.16).
- `package_weight_kg` has only a weak link to cost (r = 0.10).
- Categorical summaries: 9 delivery partners (most frequent: Xpressbees), 9 package types, 6 vehicle types, 4 delivery modes, 5 regions and 6 weather conditions. The most common `delivery_status` is `delivered` and the most common `delayed` value is `no`.
- `delivery_time_hours` and `expected_time_hours` are read as text values that look like `1970-01-01 00:00:00.000000008`, so pandas stores them as `object` and they are left out of the numerical statistics. `delivery_id` is also stored as a float with non-integer values (for example 250.99). Both look like formatting issues in the source CSV and would need cleaning before modelling.

## 13. Visualisations and Interpretation

| Plot | Interpretation |
|---|---|
| ![Histograms](outputs/01_numerical_feature_histograms.png) | `distance_km`, `package_weight_kg` and `delivery_cost` are spread roughly uniformly across their ranges. `delivery_rating` is discrete (1 to 5) and skewed towards 4 and 5. |
| ![Correlation heatmap](outputs/02_correlation_heatmap.png) | The only strong relationship is between `distance_km` and `delivery_cost` (0.99). All other pairs are weak. |
| ![Missing values](outputs/03_missing_values_bar_chart.png) | Every bar is zero, confirming there are no missing values in any column. |

## 14. Conclusion

The delivery dataset is complete and free of duplicates, with 25,000 records across 15 features. Delivery cost is almost entirely explained by distance, while ratings fall slightly as distance and cost increase. The two time columns and the ID column are stored in unexpected formats and would need cleaning before they are used in a model.
