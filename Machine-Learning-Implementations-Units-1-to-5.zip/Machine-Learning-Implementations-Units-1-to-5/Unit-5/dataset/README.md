# Unit 5 Dataset

**Kaggle competition:** [Store Sales: Time Series Forecasting](https://www.kaggle.com/competitions/store-sales-time-series-forecasting) (Corporación Favorita grocery sales, Ecuador).

Files in the archive: `train.csv`, `test.csv`, `stores.csv`, `oil.csv`, `holidays_events.csv`, `transactions.csv`, `sample_submission.csv`. The notebook uses `train.csv`, `stores.csv`, `oil.csv` and `holidays_events.csv`.

**Not included in this repository.** Kaggle competition data is shared under the competition's rules and `train.csv` alone has about 3 million rows, so it is not redistributed here.

## How to get it

1. Sign in to Kaggle, open the competition page and accept the competition rules.
2. On the **Data** tab, click **Download All** to get `store-sales-time-series-forecasting.zip`.
3. Run the first notebook cell in Colab and upload that ZIP. The notebook extracts it to `/content/store_sales`.
