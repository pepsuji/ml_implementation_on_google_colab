# Unit 5: Perishable Product Demand Forecasting with CART Regression

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/pepsuji/Machine-Learning-Implementations-Units-1-to-5/blob/main/Unit-5/Unit_5_Implementation.ipynb)

**Notebook:** [`Unit_5_Implementation.ipynb`](Unit_5_Implementation.ipynb)

## 1. Project Title

Daily Demand Forecasting for Perishable Grocery Products Using CART (Decision Tree) Regression.

## 2. Problem Statement

Perishable products spoil quickly, so over-stocking causes waste and under-stocking causes lost sales. The task is to predict next-day unit sales for each store and perishable product family from calendar information, promotions, holidays, oil prices and recent sales history.

## 3. Objective

- Combine sales, store, holiday and oil-price data into one modelling table.
- Engineer date, lag and rolling-average features without using future information.
- Train a CART regression tree and evaluate it on the most recent 90 days.
- Identify the most important drivers of demand and export a prediction report.

## 4. Dataset Description and Source

**Dataset:** Kaggle competition [Store Sales: Time Series Forecasting](https://www.kaggle.com/competitions/store-sales-time-series-forecasting) (Corporación Favorita grocery stores, Ecuador), uploaded to Colab as `store-sales-time-series-forecasting.zip`.

Files used by the notebook:

| File | Content |
|---|---|
| `train.csv` | Daily sales by date, store and product family (3,000,888 rows; columns used: `date`, `store_nbr`, `family`, `sales`, `onpromotion`) |
| `stores.csv` | Store city, state, type and cluster |
| `holidays_events.csv` | Holidays and events by date |
| `oil.csv` | Daily oil price (`dcoilwtico`) |

The archive also contains `test.csv`, `transactions.csv` and `sample_submission.csv`, which are not used.

The competition data is not included in this repository; see [`dataset/README.md`](dataset/README.md) for how to download it.

## 5. Machine Learning Algorithm Used

**CART regression** (`sklearn.tree.DecisionTreeRegressor`): a binary decision tree that splits the data to minimise squared error and predicts the mean sales of each leaf.

```python
DecisionTreeRegressor(criterion="squared_error", max_depth=18,
                      min_samples_split=60, min_samples_leaf=30, random_state=42)
```

The depth and leaf-size limits control overfitting.

## 6. Libraries and Dependencies

`pandas`, `numpy`, `matplotlib`, `seaborn`, `scikit-learn` (`DecisionTreeRegressor`, `ColumnTransformer`, `OneHotEncoder`, `Pipeline`, `plot_tree`, metrics), `zipfile`, `google.colab`.

## 7. Data Preprocessing Steps

1. Load `train.csv` with compact data types and parsed dates.
2. Keep the nine perishable families: PRODUCE, DAIRY, BREAD/BAKERY, MEATS, POULTRY, EGGS, SEAFOOD, DELI, PREPARED FOODS (**818,424 rows, 54 stores**).
3. Merge store details from `stores.csv`.
4. Build a daily `is_holiday` flag from holiday types `Holiday`, `Additional` and `Event`; fill non-holiday dates with 0.
5. Interpolate missing oil prices linearly, then forward- and back-fill; merge by date.
6. Drop any remaining rows with missing values.

## 8. Feature Selection or Engineering

- **Calendar:** `year`, `month`, `day`, `day_of_week`, `is_weekend`.
- **Lag features** (per store and family): `lag_1`, `lag_7`, `lag_14`.
- **Rolling averages** (per store and family, shifted by one day so only past sales are used): `rolling_mean_7`, `rolling_mean_14`.
- **Context:** `onpromotion`, `is_holiday`, `dcoilwtico`.
- **Categorical** (one-hot encoded): `store_nbr`, `family`, `city`, `state`, `type`.

18 input features in total; after dropping rows without enough history there are **811,620 rows**.

## 9. Model Implementation

```python
cart_model = Pipeline([
    ("preprocessing", ColumnTransformer(
        [("categorical", OneHotEncoder(handle_unknown="ignore"), categorical_features)],
        remainder="passthrough")),
    ("regressor", DecisionTreeRegressor(...)),
])
```

## 10. Training and Testing Methodology

Chronological split: the last 90 days are held out for testing, so the model is always evaluated on dates after the ones it was trained on.

| | Records | Period |
|---|---|---|
| Training | 767,394 | 15 Jan 2013 to 16 May 2017 |
| Testing | 44,226 | 17 May 2017 to 15 Aug 2017 |

## 11. Evaluation Metrics

Mean Absolute Error (MAE), Root Mean Squared Error (RMSE) and R².

## 12. Actual Results and Observations

| Metric | Value |
|---|---|
| MAE | **69.071** units |
| RMSE | **166.349** units |
| R² | **0.9769** |

Top features by importance:

| Feature | Importance |
|---|---|
| rolling_mean_7 | 0.6153 |
| lag_7 | 0.3209 |
| lag_14 | 0.0271 |
| lag_1 | 0.0239 |
| rolling_mean_14 | 0.0031 |
| day | 0.0025 |
| day_of_week | 0.0017 |
| onpromotion | 0.0016 |

Observations:

- The model explains about 97.7% of the variance in daily sales over the 90-day test period.
- Recent sales history dominates: the 7-day rolling mean and the same weekday last week (`lag_7`) together account for about 94% of the importance, which reflects strong weekly seasonality.
- Promotions, holidays, oil price and store attributes contribute very little once sales history is known.
- The prediction report clips negative predictions to 0 and is exported as `CART_Demand_Predictions.csv`.

## 13. Visualisations and Interpretation

| Plot | Interpretation |
|---|---|
| ![Sales distribution](outputs/01_sales_distribution.png) | Daily sales per store and family are heavily right-skewed: almost all values fall in the lowest bin, with a long tail reaching about 90,000 units. |
| ![Demand by category](outputs/02_average_demand_by_category.png) | Average daily units sold by perishable family. |
| ![Daily trend](outputs/03_daily_sales_trend.png) | Total perishable sales rise from about 100,000 units a day in 2013 to about 250,000 to 300,000 by 2016 and 2017, with clear weekly cycles, step changes in 2014 and 2015, and near-zero dips on 1 January each year when stores are closed. |
| ![Promotion](outputs/04_sales_by_promotion.png) | Average sales by number of products on promotion. |
| ![Actual vs predicted scatter](outputs/05_actual_vs_predicted_scatter.png) | Points lie close to the diagonal across the full range up to about 15,000 units, with wider spread at the highest sales values. |
| ![Actual vs predicted over time](outputs/06_actual_vs_predicted_over_time.png) | Summed across all stores and families, predicted demand tracks the weekly peaks and troughs of actual demand through the test period. |
| ![Feature importance](outputs/07_feature_importance.png) | `rolling_mean_7` and `lag_7` dominate. |
| ![Decision tree](outputs/08_cart_decision_tree.png) | The top three levels of the fitted tree. Features appear by index after encoding: `x[117]` is `rolling_mean_7`, `x[115]` is `lag_7`, `x[114]` is `lag_1`, `x[116]` is `lag_14` and `x[118]` is `rolling_mean_14`. The root splits on `rolling_mean_7 <= 3489.6`, and every split shown uses a lag or rolling-mean feature. |

## 14. Conclusion

A CART regression tree with lag and rolling-mean features forecasts daily demand for perishable products with R² = 0.9769, MAE = 69.07 and RMSE = 166.35 on the last 90 days of data. Recent sales history, especially the 7-day rolling average and last week's sales, drives almost all of the predictive power. A single tree is easy to interpret; ensemble methods such as Random Forest or gradient boosting could be tried next to reduce error further.

## Notes on the Notebook

- In the "Average Daily Demand by Product Category" cell, the plotting code appears twice, so the plot is drawn twice. The code is kept as in the original; only one copy of the image is saved in `outputs/`.
