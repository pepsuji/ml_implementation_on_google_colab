# Unit 2: Property Price Prediction with Ridge Regression

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/pepsuji/Machine-Learning-Implementations-Units-1-to-5/blob/main/Unit-2/Unit_2_Implementation.ipynb)

**Notebook:** [`Unit_2_Implementation.ipynb`](Unit_2_Implementation.ipynb)

## 1. Project Title

Property Price Prediction Using Ridge (L2-Regularised) Linear Regression.

## 2. Problem Statement

Predict the listed price of a residential property in Indian cities from its type, location, size, configuration and listing attributes, using a regularised linear model that can handle a large number of one-hot encoded location features.

## 3. Objective

- Build a complete scikit-learn pipeline (imputation, scaling, one-hot encoding, Ridge regression).
- Remove identifier and leakage-prone price columns before training.
- Tune the regularisation strength `alpha` with 5-fold cross-validation.
- Evaluate the model on a held-out test set and inspect its coefficients.

## 4. Dataset Description and Source

| Property | Value |
|---|---|
| File | `RE_Combined_Data.xlsx` (inside a ZIP uploaded to Colab) |
| Rows | 33,931 |
| Columns | 30 |
| Target | `PRICE` |
| Cities | 17 (for example Gurgaon, Hyderabad, Kolkata, Mumbai areas) |
| Unique addresses | 192 |

Property types: Apartment (28,408), Independent/Builder Floor (2,890), Apartment Land (2,050), Independent House/Villa (358), Studio Apartment (159), Serviced Apartments (58), Farm House (7), Other (1).

Several columns are largely empty: `ADDRESS`, `BATHROOM_NUM`, `CONTACT_COMPANY_NAME`, `BROKERAGE` and `CARPET_SQFT` each have 24,437 missing values; `SUPERBUILTUP_SQFT` has 16,091; and `BUILDING_ID`, `MIN_PRICE`, `MAX_PRICE`, `MIN_AREA_SQFT`, `MAX_AREA_SQFT`, `EXPIRY_DATE` and `CLASS_LABEL` have 8,346 each.

**Source:** the dataset was supplied as `unit_2_dataset.zip` and is included in [`dataset/`](dataset/). The notebook does not record its original download page; see [`dataset/README.md`](dataset/README.md).

## 5. Machine Learning Algorithm Used

**Ridge Regression** (`sklearn.linear_model.Ridge`): linear regression with an L2 penalty on the coefficients, which shrinks them towards zero and keeps the model stable when there are many correlated one-hot features.

## 6. Libraries and Dependencies

`pandas`, `numpy`, `matplotlib`, `seaborn`, `scikit-learn` (`train_test_split`, `GridSearchCV`, `ColumnTransformer`, `Pipeline`, `OneHotEncoder`, `StandardScaler`, `SimpleImputer`, `Ridge`, metrics), `openpyxl` (for `pd.read_excel`), `zipfile`, `glob`, `google.colab`.

## 7. Data Preprocessing Steps

1. Drop rows with a missing `PRICE` (none were missing).
2. Fill missing categorical values with `"Missing"` and cast them to strings, which avoids mixed-type errors in one-hot encoding.
3. Numerical columns: median imputation, then `StandardScaler`.
4. Categorical columns: most-frequent imputation, then `OneHotEncoder(handle_unknown="ignore")`.
5. Steps 3 and 4 are combined in a `ColumnTransformer` inside the model pipeline, so they are fitted only on training folds.

## 8. Feature Selection or Engineering

Eleven columns are removed because they are identifiers, free text or derived from the price (leakage risk): `PRICE`, `PROP_ID`, `BUILDING_ID`, `PROP_NAME`, `CONTACT_COMPANY_NAME`, `PRICE_SQFT`, `PRICE_PER_UNIT_AREA`, `MIN_PRICE`, `MAX_PRICE`, `EXPIRY_DATE`, `CLASS_LABEL`.

The remaining 19 input features are:

- **Categorical (7):** `PROPERTY_TYPE`, `CITY`, `ADDRESS`, `RESALE`, `OWNTYPE`, `FURNISH`, `FACING`
- **Numerical (12):** `BEDROOM_NUM`, `BATHROOM_NUM`, `BALCONY_NUM`, `AGE`, `FLOOR_NUM`, `TOTAL_FLOOR`, `CARPET_SQFT`, `SUPERBUILTUP_SQFT`, `BROKERAGE`, `MIN_AREA_SQFT`, `MAX_AREA_SQFT`, `TOTAL_LANDMARK_COUNT`

After one-hot encoding the model sees **240 features** (12 numerical + 228 encoded categorical).

## 9. Model Implementation

```python
ridge_pipeline = Pipeline(steps=[
    ("preprocessor", preprocessor),   # ColumnTransformer: numeric + categorical
    ("ridge", Ridge())
])
```

## 10. Training and Testing Methodology

- Random 80/20 split with `random_state=42`: **27,144 training** and **6,787 test** samples.
- `GridSearchCV` over `alpha ∈ {0.01, 0.1, 1, 10, 100, 1000}` with 5-fold cross-validation and R² scoring.
- The best pipeline is refitted on the full training set and evaluated on the test set.

## 11. Evaluation Metrics

Mean Absolute Error (MAE), Mean Squared Error (MSE), Root Mean Squared Error (RMSE) and the coefficient of determination (R²).

## 12. Actual Results and Observations

| Metric | Value |
|---|---|
| Best alpha | 10 |
| Best cross-validation R² | 0.5885 |
| Test R² | **0.6122** |
| Test MAE | 4,387.21 |
| Test MSE | 78,492,122.93 |
| Test RMSE | 8,859.58 |

Cross-validation R² by alpha:

| alpha | 0.01 | 0.1 | 1 | 10 | 100 | 1000 |
|---|---|---|---|---|---|---|
| Mean CV R² | 0.5880 | 0.5880 | 0.5882 | **0.5885** | 0.5860 | 0.5516 |

Observations:

- The model explains about 61% of the variance in price on unseen data.
- Performance is nearly flat for alpha between 0.01 and 100 and drops at 1000, where the penalty is strong enough to underfit.
- `PRICE` is extremely skewed: the median is 28 but the mean is 5,124 and the maximum is 99,000. The plots show two separate groups of prices, very small values and values in the thousands, which suggests the column mixes different price scales or units.
- Because of this, some test predictions are negative (for example -1,925 and -2,070 in the first ten predictions), and predictions for the high-price group level off at about 30,000 to 40,000.
- The largest coefficients belong to `OWNTYPE` categories (for example `OWNTYPE_Renter`) and property type, followed by specific locations such as `Rosewood` and `Sector 66 Gurgaon`.

## 13. Visualisations and Interpretation

| Plot | Interpretation |
|---|---|
| ![Top locations](outputs/01_top15_locations.png) | Listings are concentrated in Gurgaon sectors; Sector 65 Gurgaon has the most (326). |
| ![Price distribution](outputs/02_price_distribution.png) | Almost all prices fall in the first bin near zero, with a long thin tail up to 99,000. |
| ![Actual vs predicted](outputs/03_actual_vs_predicted.png) | Points form two groups instead of following the diagonal: low actual prices are predicted around zero (including negative values), and high actual prices are under-predicted and level off near 30,000 to 40,000. |
| ![Residuals](outputs/04_residual_plot.png) | Residuals are not random. A straight diagonal band near zero and a wide spread above 10,000 show the linear model cannot fit both price groups at once. |
| ![Ridge coefficients](outputs/05_top15_ridge_coefficients.png) | Ownership type, property type and a few addresses have the largest influence on the predicted price. |
| ![Alpha vs R²](outputs/06_alpha_vs_cv_r2.png) | Cross-validated R² stays near 0.588 up to alpha = 10 and falls as alpha grows larger. |

## 14. Conclusion

A Ridge Regression pipeline with leakage-safe feature selection, imputation, scaling and one-hot encoding reached a test R² of 0.6122 with alpha = 10. The residual pattern shows the main limitation is the target itself: `PRICE` appears to mix different scales, which a single linear model cannot fit. Converting all prices to one unit, or modelling a log-transformed price, would be the most useful next step.
