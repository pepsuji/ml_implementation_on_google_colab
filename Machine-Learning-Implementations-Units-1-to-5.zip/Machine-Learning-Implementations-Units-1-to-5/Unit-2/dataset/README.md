# Unit 2 Dataset

**File:** [`RE_Combined_Data.zip`](RE_Combined_Data.zip) (4.9 MB), containing `RE_Combined_Data.xlsx`.

| Property | Value |
|---|---|
| Rows | 33,931 |
| Columns | 30 |
| Target | `PRICE` |
| Content | Residential property listings across 17 Indian city areas (Gurgaon, Hyderabad, Kolkata, Mumbai and others) |

The notebook does not record the original public source of this file.

## How to use it

When the upload cell runs in Colab, choose `RE_Combined_Data.zip`. The notebook extracts it to `/content/real_estate_data` and loads the first `.xlsx` file it finds.
