# Unit 3 Dataset

**Kodak Lossless True Color Image Suite**: 24 PNG images (`kodim01.png` to `kodim24.png`), 768 × 512 pixels each.

**Source:** Kaggle, [`sherylmehta/kodak-dataset`](https://www.kaggle.com/datasets/sherylmehta/kodak-dataset) (about 14.7 MB).

**Not stored in this repository**, because the notebook downloads it automatically in its first cell:

```python
import kagglehub
path = kagglehub.dataset_download("sherylmehta/kodak-dataset")
```

In Google Colab this works without any setup. If Kaggle asks for authentication, sign in to Kaggle and add your API credentials as described in the [kagglehub documentation](https://github.com/Kaggle/kagglehub).
