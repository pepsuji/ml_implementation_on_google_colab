# Unit 3: Image Colour Quantization with K-Means Clustering

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/pepsuji/Machine-Learning-Implementations-Units-1-to-5/blob/main/Unit-3/Unit_3_Implementation.ipynb)

**Notebook:** [`Unit_3_Implementation.ipynb`](Unit_3_Implementation.ipynb)

> The notebook is about 12 MB because it stores many image outputs. If GitHub's preview is slow or does not load, open it with the Colab badge above or on [nbviewer](https://nbviewer.org/github/pepsuji/Machine-Learning-Implementations-Units-1-to-5/blob/main/Unit-3/Unit_3_Implementation.ipynb).

## 1. Project Title

Image Colour Quantization for Compression Using K-Means Clustering.

## 2. Problem Statement

A 24-bit RGB image can contain millions of distinct colours. Colour quantization reduces an image to a small palette of K colours so each pixel can be stored as a short palette index, which reduces storage and transmission size. The task is framed as unsupervised clustering: every pixel is a point in 3-D colour space, and the cluster centres become the palette.

## 3. Objective

- Implement K-Means colour quantization and show its effect for different K.
- Measure quality and compression with MSE, PSNR, SSIM, compression ratio and bits per pixel.
- Choose a suitable K using the elbow method, silhouette score and the rate-distortion curve.
- Compare K-Means (RGB), MiniBatchKMeans (RGB), K-Means (CIELAB) and the Median-Cut baseline.
- Check how well edges are preserved and compare real file sizes.

## 4. Dataset Description and Source

| Property | Value |
|---|---|
| Dataset | Kodak Lossless True Color Image Suite |
| Images | 24 PNG images (`kodim01.png` to `kodim24.png`) |
| Resolution | 768 × 512 pixels, landscape or portrait (first image array shape: 512 × 768 × 3) |
| Source | Kaggle: [`sherylmehta/kodak-dataset`](https://www.kaggle.com/datasets/sherylmehta/kodak-dataset) |

The notebook downloads the dataset automatically with `kagglehub.dataset_download("sherylmehta/kodak-dataset")`, so no files need to be uploaded. See [`dataset/README.md`](dataset/README.md).

## 5. Machine Learning Algorithm Used

- **K-Means clustering** (`sklearn.cluster.KMeans`, `k-means++` initialisation, `n_init=3`): the core method.
- For comparison: **MiniBatchKMeans** (RGB), **K-Means in CIELAB colour space**, and Pillow's **Median-Cut** quantizer as a non-learning baseline.
- `GaussianMixture` is imported but not used.

## 6. Libraries and Dependencies

`numpy`, `pandas`, `matplotlib`, `Pillow`, `scikit-learn`, `scikit-image`, `scipy`, `tqdm`, `kagglehub`.

## 7. Data Preprocessing Steps

1. Load every image and convert it to RGB.
2. Reshape each image from (H, W, 3) to an (H×W, 3) array of `float32` pixels.
3. For the CIELAB variant, convert the image with `skimage.color.rgb2lab` before clustering and back with `lab2rgb` afterwards.

## 8. Feature Selection or Engineering

Each pixel's three colour values (R, G, B, or L\*, a\*, b\* for the CIELAB variant) are the features. No other features are derived.

## 9. Model Implementation

```python
def quantize_kmeans(image, k):
    pixels = image_to_pixels(image)
    kmeans = KMeans(n_clusters=k, init="k-means++", n_init=3, random_state=42)
    labels = fit_and_predict_subsampled(kmeans, pixels)   # fit on up to 50,000 pixels
    palette = np.round(kmeans.cluster_centers_).astype(np.uint8)
    return pixels_to_image(palette[labels], image.shape), palette, labels, kmeans.inertia_
```

To keep runtime low, each model is fitted on a random subsample of up to 50,000 pixels and then used to label every pixel in the image.

## 10. Training and Testing Methodology

As an unsupervised task there is no train-test split. Instead:

- **K sweep:** all 24 images × K ∈ {2, 4, 8, 16, 32, 64, 128, 256}, with metrics recorded for every combination (saved as `results_kmeans.csv`).
- **Choosing K:** elbow curves (inertia) for three images and the mean silhouette score on a 10,000-pixel subsample of three images for K ∈ {2, 4, 8, 16, 32}.
- **Method comparison:** all four methods on all 24 images at K = 16 and K = 64, including runtime.
- **Edge preservation:** Canny edges of the original vs. quantized image, scored with F1.
- **Transmission simulation:** saving the quantized image as an indexed PNG and comparing file sizes.

## 11. Evaluation Metrics

- **MSE** and **PSNR** (dB): pixel-level reconstruction error.
- **SSIM**: perceived structural similarity.
- **Compression ratio** and **bits per pixel (bpp)**: theoretical storage from palette indices plus the palette.
- **Inertia** and **silhouette score**: cluster quality.
- **Edge preservation F1**: overlap of Canny edge maps.
- **Runtime** in seconds.

## 12. Actual Results and Observations

Method comparison (mean over 24 images):

| K | Method | PSNR (dB) | SSIM | Compression ratio | Time (s) |
|---|---|---|---|---|---|
| 16 | K-Means RGB | **30.21** | **0.881** | 6.00 | 0.238 |
| 16 | MiniBatchKMeans RGB | 30.01 | 0.879 | 6.00 | 0.062 |
| 16 | K-Means CIELAB | 28.68 | 0.836 | 6.00 | 0.358 |
| 16 | Median-Cut | 27.18 | 0.876 | 6.00 | 0.096 |
| 64 | K-Means RGB | **35.86** | **0.951** | 4.00 | 0.877 |
| 64 | MiniBatchKMeans RGB | 35.59 | 0.950 | 4.00 | 0.169 |
| 64 | K-Means CIELAB | 33.82 | 0.920 | 4.00 | 1.042 |
| 64 | Median-Cut | 32.07 | 0.941 | 4.00 | 0.097 |

Edge preservation on `kodim01.png`:

| K | 8 | 16 | 32 |
|---|---|---|---|
| Edge F1 | 0.809 | 0.894 | 0.933 |

File sizes for `kodim01.png`: original PNG **762.14 KB**, JPEG (quality 90) **151.35 KB**, quantized indexed PNG at K = 16 **110.56 KB**.

Best and worst images at K = 16 by PSNR: best `kodim16`, `kodim01`, `kodim02`; worst `kodim23`, `kodim05`, `kodim14`.

Observations:

- K-Means in RGB gives the highest PSNR and SSIM at both K values. MiniBatchKMeans is within about 0.2 to 0.3 dB of it while running roughly 4 to 5 times faster.
- K-Means in CIELAB scores lower on PSNR and SSIM, which are measured in RGB space.
- Median-Cut is the fastest but has the lowest PSNR.
- The notebook recommends **K = 16** as the trade-off point between quality and compression.

## 13. Visualisations and Interpretation

| Plot | Interpretation |
|---|---|
| ![Sample images](outputs/01_sample_kodak_images.png) | The first six Kodak images, used to confirm the data loaded correctly. |
| ![K values](outputs/02_kmeans_quantization_k_values.png) | Quantized versions of `kodim01` at K = 4 to 64 with their palettes. Detail and colour accuracy improve quickly up to K = 16. |
| ![Metrics vs K](outputs/03_psnr_ssim_ratio_vs_k.png) | PSNR and SSIM rise with K, while the compression ratio falls. |
| ![Rate-distortion](outputs/04_rate_distortion_curve.png) | Each extra bit per pixel gives a smaller PSNR gain at higher K (diminishing returns). |
| ![Elbow](outputs/05_elbow_curve.png) | Inertia drops sharply for small K and flattens as K grows. |
| ![Silhouette](outputs/06_silhouette_score_vs_k.png) | Silhouette score is highest around K = 4 (about 0.52) and falls to about 0.41 at K = 16 and 0.36 at K = 32. |
| ![Comparison K=16](outputs/07_method_comparison_k16.png) ![Comparison K=64](outputs/08_method_comparison_k64.png) | PSNR and SSIM by method at K = 16 and K = 64. |
| ![Visual comparison](outputs/09_method_visual_comparison_k16.png) | Side-by-side output of the four methods at K = 16. |
| ![Edges](outputs/10_edge_preservation.png) | Canny edge maps; more edges are preserved as K increases. |
| ![Best cases](outputs/11_best_cases_k16.png) ![Worst cases](outputs/12_worst_cases_k16.png) | Images with large smooth areas quantize well; highly textured, colourful images have the lowest PSNR. |

## 14. Conclusion

K-Means colour quantization compresses images effectively: at K = 16 it reaches about 30 dB PSNR and 0.88 SSIM with a 6:1 theoretical compression ratio, and the indexed PNG for `kodim01` is smaller than a quality-90 JPEG. K-Means in RGB space gives the best quality, MiniBatchKMeans gives nearly the same quality much faster, and Median-Cut is the fastest baseline. The notebook notes colour banding as a limitation and suggests dithering (for example Floyd-Steinberg) and adaptive regional palettes as future work.
