# Machine Learning Implementations – Units 1 to 5

![Python](https://img.shields.io/badge/Python-3-3776AB?logo=python&logoColor=white)
![Jupyter](https://img.shields.io/badge/Jupyter-Notebook-F37626?logo=jupyter&logoColor=white)
![scikit-learn](https://img.shields.io/badge/scikit--learn-ML-F7931E?logo=scikitlearn&logoColor=white)
![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)

Five Machine Learning implementations built in Google Colab, one per course unit. They cover exploratory data analysis, regularised linear regression, unsupervised clustering, ensemble classification and decision-tree regression, each on a real-world dataset with documented results.

## Table of Contents

- [Overview](#overview)
- [Academic Purpose](#academic-purpose)
- [Objectives](#objectives)
- [Implementation Summary](#implementation-summary)
- [Unit-wise Overview](#unit-wise-overview)
- [Algorithms Used](#algorithms-used)
- [Datasets](#datasets)
- [Technologies and Libraries](#technologies-and-libraries)
- [Installation](#installation)
- [Running the Notebooks in Google Colab](#running-the-notebooks-in-google-colab)
- [Repository Structure](#repository-structure)
- [Summary of Results](#summary-of-results)
- [Conclusion](#conclusion)

## Overview

Each unit lives in its own folder with:

- the original Colab notebook, with all code, printed outputs and plots preserved,
- a README that explains the problem, data, method, evaluation and results,
- an `outputs/` folder with the plots exported from the notebook,
- a `dataset/` folder with the data or instructions for downloading it.

## Academic Purpose

These notebooks were written as practical work for a Machine Learning course. Together they follow the typical workflow of an ML project: understanding the data, preparing it, choosing and training a model, evaluating it honestly, and interpreting the results.

## Objectives

- Explore and summarise a dataset statistically before modelling.
- Build reproducible scikit-learn pipelines for preprocessing and modelling.
- Apply supervised regression, supervised classification and unsupervised clustering.
- Use evaluation methods that avoid data leakage: cross-validation, group-aware splits and time-based splits.
- Interpret models through metrics, residuals, confusion matrices and feature importance.

## Implementation Summary

| Unit | Project Title | Algorithm | Dataset | Implementation |
|------|---------------|-----------|---------|----------------|
| 1 | Dataset Exploration and Statistical Analysis | Exploratory data analysis and descriptive statistics | Delivery Logistics (25,000 deliveries) | [Notebook](Unit-1/Unit_1_Implementation.ipynb) · [README](Unit-1/README.md) |
| 2 | Property Price Prediction | Ridge Regression with GridSearchCV | Indian real-estate listings, `RE_Combined_Data.xlsx` (33,931 rows) | [Notebook](Unit-2/Unit_2_Implementation.ipynb) · [README](Unit-2/README.md) |
| 3 | Image Colour Quantization | K-Means clustering (vs. MiniBatchKMeans, CIELAB K-Means, Median-Cut) | Kodak image suite (24 images, Kaggle) | [Notebook](Unit-3/Unit_3_Implementation.ipynb) · [README](Unit-3/README.md) |
| 4 | Sleep Stage Classification from Heart Rate | Random Forest Classifier | Minute-level heart rate and sleep stages (34,403 readings) | [Notebook](Unit-4/Unit_4_Implementation.ipynb) · [README](Unit-4/README.md) |
| 5 | Perishable Product Demand Forecasting | CART (Decision Tree) Regression | Kaggle Store Sales: Time Series Forecasting (Favorita) | [Notebook](Unit-5/Unit_5_Implementation.ipynb) · [README](Unit-5/README.md) |

## Unit-wise Overview

### [Unit 1: Dataset Exploration and Statistical Analysis](Unit-1/README.md)
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/pepsuji/Machine-Learning-Implementations-Units-1-to-5/blob/main/Unit-1/Unit_1_Implementation.ipynb)

Loads a 25,000-row delivery logistics dataset, checks its structure and quality, computes descriptive statistics, and plots histograms, a correlation heatmap and missing values. Key finding: delivery cost is almost entirely determined by distance (r = 0.99).

### [Unit 2: Property Price Prediction with Ridge Regression](Unit-2/README.md)
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/pepsuji/Machine-Learning-Implementations-Units-1-to-5/blob/main/Unit-2/Unit_2_Implementation.ipynb)

Predicts property prices with a pipeline of imputation, scaling, one-hot encoding (240 features) and Ridge regression, with alpha tuned by 5-fold GridSearchCV. Leakage-prone price columns are removed before training.

### [Unit 3: Image Colour Quantization with K-Means](Unit-3/README.md)
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/pepsuji/Machine-Learning-Implementations-Units-1-to-5/blob/main/Unit-3/Unit_3_Implementation.ipynb)

Treats each pixel as a point in colour space and clusters it to build a K-colour palette. Sweeps K from 2 to 256 on all 24 Kodak images, chooses K with elbow, silhouette and rate-distortion analysis, compares four quantization methods, and checks edge preservation and real file sizes.

### [Unit 4: Sleep Stage Classification with Random Forest](Unit-4/README.md)
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/pepsuji/Machine-Learning-Implementations-Units-1-to-5/blob/main/Unit-4/Unit_4_Implementation.ipynb)

Splits a heart-rate log into 98 recording sessions, engineers 5-minute rolling heart-rate features, and classifies light, deep and REM sleep with a Random Forest. Evaluation uses a session-grouped split so no recording session appears in both training and testing.

### [Unit 5: Demand Forecasting with CART Regression](Unit-5/README.md)
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/pepsuji/Machine-Learning-Implementations-Units-1-to-5/blob/main/Unit-5/Unit_5_Implementation.ipynb)

Merges store, holiday and oil-price data with daily sales of nine perishable product families, builds lag and rolling-mean features, and trains a regression tree. The last 90 days are held out to test forecasting on unseen dates.

## Algorithms Used

| Unit | Algorithm | Type | Library |
|---|---|---|---|
| 1 | Descriptive statistics, correlation analysis | Exploratory analysis | pandas, seaborn |
| 2 | Ridge Regression (L2 regularisation) | Supervised regression | `sklearn.linear_model.Ridge` |
| 3 | K-Means, MiniBatchKMeans | Unsupervised clustering | `sklearn.cluster` |
| 4 | Random Forest | Supervised classification (ensemble) | `sklearn.ensemble.RandomForestClassifier` |
| 5 | CART regression tree | Supervised regression | `sklearn.tree.DecisionTreeRegressor` |

## Datasets

| Unit | Dataset | In this repo? | How to get it |
|---|---|---|---|
| 1 | `Delivery_Logistics.csv` | No | Original source not recorded; see [Unit-1/dataset](Unit-1/dataset/README.md) |
| 2 | `RE_Combined_Data.xlsx` | Yes, [`RE_Combined_Data.zip`](Unit-2/dataset/RE_Combined_Data.zip) | Upload the ZIP in Colab |
| 3 | Kodak image suite | No (downloaded by the notebook) | Kaggle [`sherylmehta/kodak-dataset`](https://www.kaggle.com/datasets/sherylmehta/kodak-dataset) |
| 4 | `Heartrate_sleep_data.csv` | No | Original source not recorded; format in [Unit-4/dataset](Unit-4/dataset/README.md) |
| 5 | Store Sales (Favorita) | No (competition data) | [Kaggle competition](https://www.kaggle.com/competitions/store-sales-time-series-forecasting) |

## Technologies and Libraries

- **Language:** Python 3
- **Environment:** Google Colab / Jupyter Notebook
- **Data handling:** pandas, NumPy
- **Visualisation:** Matplotlib, Seaborn
- **Machine learning:** scikit-learn
- **Image processing (Unit 3):** Pillow, scikit-image, SciPy
- **Other:** joblib (model saving), openpyxl (Excel input), tqdm, kagglehub

## Installation

The notebooks were written for Google Colab, where all libraries are already installed. To run them locally:

```bash
git clone https://github.com/pepsuji/Machine-Learning-Implementations-Units-1-to-5.git
cd Machine-Learning-Implementations-Units-1-to-5
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
jupyter notebook
```

The notebooks use `google.colab.files` to upload data. When running locally, replace those cells with a direct file path, for example `pd.read_csv("dataset/Delivery_Logistics.csv")`.

## Running the Notebooks in Google Colab

1. Click the **Open in Colab** badge for the unit you want.
2. In Colab, choose **Runtime → Run all**.
3. When a cell asks for a file, upload the dataset listed in that unit's `dataset/README.md`:
   - Unit 1: `Delivery_Logistics.csv`
   - Unit 2: `RE_Combined_Data.zip`
   - Unit 3: nothing to upload (downloaded from Kaggle automatically)
   - Unit 4: `Heartrate_sleep_data.csv`
   - Unit 5: `store-sales-time-series-forecasting.zip` from Kaggle

## Repository Structure

```
Machine-Learning-Implementations-Units-1-to-5/
├── README.md
├── LICENSE
├── requirements.txt
├── .gitignore
├── Unit-1/
│   ├── README.md
│   ├── Unit_1_Implementation.ipynb
│   ├── dataset/README.md
│   └── outputs/              # 3 plots
├── Unit-2/
│   ├── README.md
│   ├── Unit_2_Implementation.ipynb
│   ├── dataset/
│   │   ├── README.md
│   │   └── RE_Combined_Data.zip
│   └── outputs/              # 6 plots
├── Unit-3/
│   ├── README.md
│   ├── Unit_3_Implementation.ipynb
│   ├── dataset/README.md
│   └── outputs/              # 12 plots
├── Unit-4/
│   ├── README.md
│   ├── Unit_4_Implementation.ipynb
│   ├── dataset/README.md
│   └── outputs/              # 6 plots
└── Unit-5/
    ├── README.md
    ├── Unit_5_Implementation.ipynb
    ├── dataset/README.md
    └── outputs/              # 8 plots
```

## Summary of Results

| Unit | Task | Key Result |
|---|---|---|
| 1 | EDA of 25,000 deliveries | No missing values or duplicates; distance and cost correlate at r = 0.99 |
| 2 | Ridge regression on property prices | Test R² = 0.6122, MAE = 4,387.21, RMSE = 8,859.58 (best alpha = 10, CV R² = 0.5885) |
| 3 | K-Means colour quantization (K = 16) | PSNR = 30.21 dB, SSIM = 0.881, compression ratio ≈ 6:1; indexed PNG 110.56 KB vs. 762.14 KB original |
| 4 | Random Forest sleep staging | Accuracy = 62.47% on unseen sessions, macro F1 = 0.61 |
| 5 | CART demand forecasting | R² = 0.9769, MAE = 69.07, RMSE = 166.35 on the last 90 days |

![Unit 3: K-Means quantization at different K](Unit-3/outputs/02_kmeans_quantization_k_values.png)

![Unit 5: Actual vs predicted demand](Unit-5/outputs/06_actual_vs_predicted_over_time.png)

## Conclusion

Across the five units:

- **Data understanding comes first.** Unit 1 shows how statistics and correlations reveal structure (and data-format problems) before any model is trained.
- **Evaluation design matters as much as the algorithm.** Units 4 and 5 use group-aware and chronological splits so the reported scores reflect performance on genuinely new data.
- **The right features drive performance.** In Unit 5, lag and rolling-mean features account for almost all of the model's predictive power.
- **Results should be read critically.** Unit 2's residual plot shows that the target variable mixes price scales, which limits any single linear model.

Each unit's README covers its method, results and limitations in detail.

## License

Code and documentation are released under the [MIT License](LICENSE). Datasets keep the licences and terms of their original sources.
